"""Ingest subpackage.

`legacy_ingest` is your original ingest.py moved verbatim.
"""

from . import legacy_ingest

__all__ = ["legacy_ingest"]
