"""Query subpackage.

`legacy_query` is your original query.py moved verbatim.
"""

from . import legacy_query

__all__ = ["legacy_query"]
